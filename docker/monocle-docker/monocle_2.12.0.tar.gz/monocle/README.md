[![Build Status](https://travis-ci.com/cole-trapnell-lab/monocle-release.svg?branch=master)](https://travis-ci.com/cole-trapnell-lab/monocle-release)

MONOCLE
=======================

Monocle is an analysis toolkit for single-cell RNA-Seq experiments.  To use this package, you 
will need the R statistical computing environment (version 3.0 or later)
and several packages available through Bioconductor and CRAN.

We highly recommend installation of Monocle through the bioconductor project. 
See here for details:

https://bioconductor.org/packages/release/bioc/html/monocle.html

News and announcements for the Monocle project will appear here:

http://cole-trapnell-lab.github.io/monocle-release/

This release supports Mac OS X and Linux. Windows may support this 
build, but Monocle has not been tested on Windows yet.
